
<?php include 'head.php';?>
       
<!-- Content Start --->
<section id="hero" class="wrapper">
    <div class="container">
        <h2>Celestial Landscapes</h2>
    </div>
</section>

<section id="features" class="wrapper">
    <div class="container">
        <article>
            <h2>On Display</h2>
            <p>Paintings at Lord Hobo in Cambridge, MA. </p>
            <a href="https://www.facebook.com/pages/Lord-Hobo/171920519015" target="_blank" class="button">Where is it?</a>
        </article>

        <article>
            <h2>New Work</h2>
            <p>Four new paintings. 24" x 24", oil on panel. </p>
            <a href="#portfolio" class="button">See them below</a>
        </article>

        <article>
            <h2>Portfolio</h2>
            <p>Sampling of work to date.</p>
            <a href="#portfolio" class="button">View Portfolio</a>
        </article>
    </div>
</section>


<section id="about" class="wrapper">
    <div class="container">
        <article>
            <h2>About the Artist</h2>
            <p>My work is a marriage between the biological and the celestial. I draw inspiration from my surrounding landscapes, and interpret them through a view you would find on the Hubble telescope.             </p>
            <p>Mark Rothko said a painting is not about an experience, it is an experience - and I tend to agree. The act of working and the finished painting alike, for me, are not dissimilar to a quiet walk through the woods; a refreshing journey, and reminder that we're a small part of something much larger and quite intricate. In this case, the experience is not meant to be as initially dramatic as a Crab Nebula or wave crashing on the shoreline, but to give an overall experience - where one might hang on the subtle moments, like a gentle breeze on a silver maple branch or a cirrus cloud beneath the milky way.</p>
        </article>
    </div>
</section>

<?php include 'panels/gallery.php';?>
<!-- Content End --->     

<?php include 'footer.php';?>




