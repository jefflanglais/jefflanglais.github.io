
<?php include 'head.php';?>
       
<!-- Content Start --->


<section class="wrapper">
    <div class="container">
        <main>
            <h2 class="page-title">The Timbers: Your dream come true. </h2>
            <p>The Timbers are much more than exceptional slopeside accommodations: they’re a place you’ll comfortably call home. Designed to reflect the very essence of Sugarloaf, each Timbers home incorporates traditional mountain style, natural materials and high-quality, state-of-the-art construction. </p>

            <p>With plans to fit every family size and any lifestyle, each Timbers home is crafted with an appreciation for detail – making it feel at once individual, and perfectly at home in both the neighborhood and its natural surroundings.</p>

            <p>Situated just seconds above the SuperQuad, the Timbers provides quick, easy access to everything Sugarloaf has to offer. From lessons and shops to restaurants and nightlife, the Timbers is situated close enough to take part in the excitement of the Resort Village – but far enough to offer quiet haven. </p>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Setting</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Incomparable ski-in/ski-out mountain setting</li>
                        <li>Within seconds of Sugarloaf/USA SuperQuad<sup>&copy;</sup></li>
                        <li>Superb views of Bigelow &amp; Sugarloaf Mountains</li>
                        <li>Within easy walking distance of Sugarloaf/USA Resort Village</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Construction</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Solid foundation of 8" x 10" concrete walls with steel reinforcement</li>
                        <li>Efficient R-38 roof insulation with ventilation channels</li>
                        <li>Sturdy 2" x 12" pre-engineered roof trusses and floor joists</li>
                        <li>Double 2" x 4" staggered studs at party walls with two layers of insulation for greater intimacy</li>
                        <li>Semi transparent stain for all exterior wood to preserve naturally rugged tones and authentic mountain lodge feel</li>
                        <li>Anderson<sup>&reg;</sup> exterior vinyl clad windows and sliding doors</li>
                        <li>30 year architectural roof shingles with 100% ice and water shield coverage</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Architecture</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Predominance of natural materials: hand-peeled logs, ragged-edge siding and cedar shingles</li>
                        <li>Steep pitched roof line with dormer windows</li>
                        <li>Sheltered entry with large timber posts and beams</li>
                        <li>Hand-peeled log collar ties and king posts at each full gable end</li>
                        <li>Private cedar wooden decks for warmer winter days and cool summer evenings</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Security and Comfort</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Lighted parking area</li>
                        <li>Three zone propane fired cast iron forced hot water heating system and separately zoned 45-gallon hot water system</li>
                        <li>Sprinklers throughout</li>
                        <li>Smoke, low temperature and carbon monoxide detectors throughout</li>
                        <li>200 amp single-phase electrical service</li>
                        <li>Air exhausts in kitchen and baths ducted to the outside</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Welcome</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Solid wood front door with window stained for natural appearance</li>
                        <li>Doorway framed by a signature metal sconce</li>
                        <li>Cedar decked covered porch with hand peeled log supports</li>
                        <li>Convenient outdoor recessed grate for scraping snow from your boots</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Hearth Area</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Cultured fieldstone fireplace with attractive doors and screen creates a dramatic focal point</li>
                        <li>A cozy foot-high hearth set one foot from the wall made with cultured stone at the base</li>
                        <li>A rugged, hand-hewn wood mantle</li>
                        <li>Soft recessed lighting directly above</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Mountain Mud Room</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Low maintenance, hand-laid, ceramic tiles</li>
                        <li>Attractive wooden bench to remove heavy boots</li>
                        <li>Ample closet with sturdy solid pine doors</li>
                        <li>Ski storage</li>
                        <li>Pine wainscoting</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Open Concept Main Floor</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Spacious 9' high ceilings</li>
                        <li>Solid maple floors factory-finished</li>
                        <li>Solid pine six-panel doors, pine baseboards, molding, and door and window casings</li>
                        <li>All woodwork stained a rich auburn</li>
                        <li>Energy-efficient, low thermo, low maintenance Andersen® windows and slider</li>
                        <li>Durable eggshell finish washable paint</li>
                        <li>Subdued recessed lighting throughout</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Gourmet Eat-In Kitchen</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Shaker-style, maple cabinetry</li>
                        <li>Solid surface counter tops and backsplash trimmed with beveled maple molding</li>
                        <li>Recessed lights</li>
                        <li>Five top-rated Kenmore<sup>&reg;</sup> appliances including: side-by-side 26 cu. ft. refrigerator complete with ice and water dispenser; an innovative combined microwave and hood; a chef's delight, self-cleaning, propane gas oven range; and dishwasher</li>
                        <li>A sitting breakfast bar area integrated into the kitchen counter</li>
                        <li>Spacious family dining area with overhead lights</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Bedrooms</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Comfortable wall to wall carpeting</li>
                        <li>High-traffic, Berber carpet</li>
                    </ul>
                </article>
            </section>
    
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Luxury Bathrooms</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Pure white sink, toilet and shower/bathtub</li>
                        <li>Delta style, single lever faucet</li>
                        <li>Chrome fixtures</li>
                        <li>Oversized vanity with drop-in sink</li>
                        <li>Wooden cabinetry same as in kitchen</li>
                        <li>Recessed lighting</li>
                        <li>Superb deluxe master bathrooms (in larger Timbers Homes) to luxuriate in after a full day of skiing: spa-style, oversized whirlpool tub with hand-laid, ceramic tile back splash; one-piece fiberglass shower; and chrome fixtures.</li>
                        <li>All bathrooms have hand-laid ceramic tile floor</li>
                    </ul>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
<!--                    <img src="img/mtside-real-estate.png"/>-->
                    <h3>Your Choice</h3>
                </figure>
                <article>
                    
                    <ul>
                        <li>Natural or auburn stain for kitchen cabinetry</li>
                        <li>Auburn or natural stain for bathroom cabinetry</li>
                        <li>Choice of white or black Kenmore® appliances</li>
                        <li>Choice of different entry sconces</li>
                        <li>Specially designed Birchwood Interiors furniture package</li>
                    </ul>
                </article>
            </section>
        
        </main>
        
        <aside>
            <h3 class="section-title">Individual Upgrades</h3>
            <p>No new home is truly yours without a personal touch. And when you make the decision to join the Timbers community, you’ll have every opportunity to participate in each and every design decision along the way. This is more than your dream home. It’s a dream come true. </p>
        </aside>
    </div>
</section>



<?php include 'panels/mountain.php';?>
<!-- Content End --->     

<?php include 'footer.php';?>