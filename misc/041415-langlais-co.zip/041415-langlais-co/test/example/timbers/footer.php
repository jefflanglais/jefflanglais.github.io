            <!-- Footer Start --->
            <footer id="contact" class="wrapper">
                <div class="container">
                    <h2>Contact Us</h2>
                    <p><a href="mailto:mtside@sugarloaf.com">Mtside@sugarloaf.com</a> ~ <b>(207) 237-2100</b></p>
                    <figure>
                        <img src="img/mtside-real-estate.png"/>
                    </figure>
                </div>
                
                <ul>
                    <li><a href="#">Sugarloaf</a></li>
                    <li><a href="#">Mountainside Real Estate</a></li>
                    <li><a href="#">Rangeley Lake Resort</a></li>
                    <li><a href="#">Rangeley, Maine</a></li>
                    <li><a href="#">Kingfield, Maine Info</a></li>
                </ul>
                <p class="copyright">Copyright <sup>&copy;</sup> 2014 Timbers-Sugarloaf</p>
                
            </footer>
            <!-- Footer End --->
        </div>
    </div>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="js/lightbox.min.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>