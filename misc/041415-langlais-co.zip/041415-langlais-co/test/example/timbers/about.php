
<?php include 'head.php';?>
       
<!-- Content Start --->


<section class="wrapper">
    <div class="container">
        <main>
            <h2 class="page-title">Stake your claim. </h2>
            <p>Ask any Sugarloafer, and they’re very likely to agree: the Timbers top the list of Sugarloaf’s premier on-mountain properties. Perched on some of the Mountain’s most beautiful terrain, the Timbers combine horizon-wide views of the Bigelows with easy slopeside access to the SuperQuad – and everything else Sugarloaf has to offer. </p>

            <p>But convenience and access are only part of the story. Perhaps the greatest appeal of the Timbers is the sense of community – with long-term owners developing close, often year-round relationships with their seasonal neighbors. Following close on community is the tasteful design and high-quality construction that marks Timbers homes. Crafted to reflect the rugged, rustic charm that defines Sugarloaf, each home fits perfectly into the mountain environment, while individual flourishes give the development a true neighborhood feel. </p>

            <p>But like so many good things, new home ownership opportunities at the Timbers are limited. With just ten build-to-suit lots remaining, we expect demand to outstrip supply sooner than later. And given the Timbers’ proven appeal – with values that consistently appreciate and exceptionally strong high-end rental performance – there’s every reason to take a closer look. </p>
        
        </main>
        
        <aside>
<!--            <h3 class="section-title">Sidebar</h3>-->
        </aside>
    </div>
</section>



<?php include 'panels/mountain.php';?>
<!-- Content End --->     

<?php include 'footer.php';?>