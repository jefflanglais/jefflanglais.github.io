
<?php include 'head.php';?>
       
<!-- Content Start --->
<section id="hero" class="wrapper">
    <div class="container">
        <h2><b>Put the SuperQuad at your back door.</b><br>
            The Timbers. Sugarloaf’s premier slopeside community.
        </h2>
    </div>
</section>

<section id="features" class="wrapper">
    <div class="container">
        <article>
            <h2>Plans &amp; Amenities</h2>
            <p>The ideal home. The perfect location. Add your wish list, and the Timbers is 100% Sugarloaf – just the way you like it.  </p>
            <a href="plans-amenities" class="button">View Plans</a>
        </article>

        <article>
            <h2>Testimonials</h2>
            <p>No one tells the Timbers story better than the people who call it home. But be warned: the stories you read may soon be your own. </p>
            <a href="testimonials" class="button">Read Testimonials</a>
        </article>

        <article>
            <h2>Photo Gallery</h2>
            <p>Seeing is believing. And at the Timbers, there’s a whole lot to see. Take a visual tour – and see what the excitement is all about. </p>
            <a href="gallery" class="button">View Gallery</a>
        </article>
    </div>
</section>

<?php include 'panels/mountain.php';?>
<?php include 'panels/map.php';?>
<!-- Content End --->     

<?php include 'footer.php';?>