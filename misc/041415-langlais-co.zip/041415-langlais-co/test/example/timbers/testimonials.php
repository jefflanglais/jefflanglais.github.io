
<?php include 'head.php';?>
       
<!-- Content Start --->


<section class="wrapper">
    <div class="container">
        <main>
            <h2 class="page-title">The Voice of Experience.</h2>
            <h3 class="section-title">The Timbers: Views from the inside.</h3>
            <p>Between their stunning location, traditional design, rugged construction and unmatched sense of community, the appeal of the Timbers speaks for itself. But when we need actual words to tell the story of life at the Timbers, our dedicated owners have plenty to say – and no one says it better. </p>
            
<!--
            <section class="teaser">
                <figure>
                    <img src="img/mtside-real-estate.png"/>
                </figure>
                <article>
                    
                    <p>Cras condimentum semper orci eu aliquam. Vivamus vitae ligula sed sapien fermentum euismod at vel turpis. Vivamus ac nisl varius, consequat erat a, dictum massa. Pellentesque aliquam nisi a metus tempus, at molestie arcu volutpat. Nullam rhoncus, elit non condimentum feugiat, libero massa varius neque, nec varius leo mauris fermentum lorem.</p>
                    <figcaption>John Doe, NC</figcaption>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
                    <img src="img/mtside-real-estate.png"/>
                </figure>
                <article>
                    
                    <p>Cras condimentum semper orci eu aliquam. Vivamus vitae ligula sed sapien fermentum euismod at vel turpis. Vivamus ac nisl varius, consequat erat a, dictum massa. Pellentesque aliquam nisi a metus tempus, at molestie arcu volutpat. Nullam rhoncus, elit non condimentum feugiat, libero massa varius neque, nec varius leo mauris fermentum lorem.</p>
                    <figcaption>John Doe, NC</figcaption>
                </article>
            </section>
            
            <section class="teaser">
                <figure>
                    <img src="img/mtside-real-estate.png"/>
                </figure>
                <article>
                    
                    <p>Cras condimentum semper orci eu aliquam. Vivamus vitae ligula sed sapien fermentum euismod at vel turpis. Vivamus ac nisl varius, consequat erat a, dictum massa. Pellentesque aliquam nisi a metus tempus, at molestie arcu volutpat. Nullam rhoncus, elit non condimentum feugiat, libero massa varius neque, nec varius leo mauris fermentum lorem.</p>
                    <figcaption>John Doe, NC</figcaption>
                </article>
            </section>
-->
            
        
        </main>
        
        <aside>
<!--            <h3 class="section-title">Sidebar</h3>-->
        </aside>
    </div>
</section>



<?php include 'panels/mountain.php';?>
<!-- Content End --->     

<?php include 'footer.php';?>