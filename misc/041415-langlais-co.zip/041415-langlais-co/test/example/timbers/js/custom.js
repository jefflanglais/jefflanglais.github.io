jQuery(document).ready(function($) {

    //==========================================================
    //  set active nav item 
    //========================================================== 
    
	var path = window.location.pathname;
    path = path.replace(/\/$/, "");
    path = decodeURIComponent(path);

    $("nav .container ul li a").each(function () {
        
        var href = $(this).attr('href');
        if (path.substring(0).indexOf(href) != -1) {
            $(this).closest('li a').addClass('active');
            $('#page-wrapper').addClass(href);
            
        }
    });
    
    var class_name = $('#page-wrapper').attr('class');
    
    
    //==========================================================
    //  detect front or not-front pages 
    //========================================================== 
    
    if(typeof class_name === 'undefined'){
        $('#page-wrapper').addClass('front');
    }
    else{
        $('#page-wrapper').addClass('not-front');
    }
    
});