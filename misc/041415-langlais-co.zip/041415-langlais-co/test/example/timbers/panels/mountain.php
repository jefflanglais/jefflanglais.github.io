<section id="mountain"class="wrapper">
    <div class="container">
    </div>
</section>