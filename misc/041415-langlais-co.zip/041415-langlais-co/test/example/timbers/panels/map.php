<section id="map"class="wrapper">
    <div class="container">
        <article>
            <h2>On the last run, head down and ski right up to your door</h2>
            <p>The Timbers provides the solid reassurance of heavy wooden doors, the earthy warmth of massive beams, and the striking beauty of maple floors and stone hearths. The Timbers’ architectural style is part mountain lodge, part New England cottage, all complete with commanding views of Bigelow and Sugarloaf Mountains.<br><br>

            <b><i>These are mountain homes you and your family will love.</i></b></p>
        </article>
        
    </div>
</section>