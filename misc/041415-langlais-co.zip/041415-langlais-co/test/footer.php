            <!-- Footer Start --->
            <footer id="contact" class="wrapper">
                
                <div class="container">
                    
                    <h2>Contact</h2>
                    <p><a href="mailto:jeff@langlais.co">jeff@langlais.co</a> ~ <b>(207) 332-4163</b></p>
                </div>
                
               
                <p class="copyright">Copyright <sup>&copy;</sup> 2015 Jeff Langlais</p>
                
            </footer>
            <!-- Footer End --->
        </div>
    </div>

    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/lightbox.min.js"></script>
    <script src="js/custom.js"></script>

    <script>
    
        var $container = $('#container').imagesLoaded( function() {
            $container.isotope({
                itemSelector: '.thumb',
                columnWidth: 200
            });
        });

    </script>
</body>
</html>