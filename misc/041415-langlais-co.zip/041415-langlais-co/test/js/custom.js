jQuery(document).ready(function($) {

    //==========================================================
    //  set active nav item 
    //========================================================== 
    
	var path = window.location.pathname;
    path = path.replace(/\/$/, "");
    path = decodeURIComponent(path);

    $("nav .container ul li a").each(function () {
        
        var href = $(this).attr('href');
        if (path.substring(0).indexOf(href) != -1) {
            $(this).closest('li a').addClass('active');
            $('#page-wrapper').addClass(href);
            
        }
    });
    
    var class_name = $('#page-wrapper').attr('class');
    
    
    //==========================================================
    //  detect front or not-front pages 
    //========================================================== 
    
    if(typeof class_name === 'undefined'){
        $('#page-wrapper').addClass('front');
    }
    else{
        $('#page-wrapper').addClass('not-front');
    }
    
    
    
     var $container = $('#portfolio section').imagesLoaded( function() {
            $container.isotope({
                itemSelector: '.thumb',
                layoutMode: 'masonry',
                masonry: {
                    columnWidth: 200
                }
                
            });
        });
    
    
    
	$(function() {
	  $('a[href*=#]:not([href=#])').click(function() {
	    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {

	      var target = $(this.hash);
	      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
	      if (target.length) {
	        $('html,body').animate({
	          scrollTop: target.offset().top
	        }, 1000);
	        return false;
	      }
	    }
	  });
	});
	
    
});