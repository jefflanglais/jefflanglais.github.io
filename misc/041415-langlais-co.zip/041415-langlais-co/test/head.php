<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title>Jeff Langlais | Painter, Fine Artist</title>
    <link rel="canonical" href="http://<?php echo $_SERVER['HTTP_HOST']; ?><?php echo parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ); ?>" />
    
    <link rel="stylesheet" href="css/global.styles.css">
    <link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,700,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
    
    <link href="css/lightbox.css" rel="stylesheet" />
</head>
    
<body>
<div id="page-wrapper">
    <div id="page">

        <!-- Header Start --->
        <header id="header" class="wrapper">
            <div class="container">
                <h1 id="logo" alt="Jeff Langlais">
                    <a href="/">Jeff Langlais</a>
                </h1>
            </div>
        </header>
        <!-- Header End --->

        <!-- Navigation Start --->
        <nav id="navigation" class="wrapper">
            <div class="container">
                <ul>
                    <li><a href="#about">About</a></li>
                    <li><a href="#portfolio">Portfolio</a></li>
                    <li><a href="#contact">Contact</a></li>
                 </ul>
            </div>
        </nav>
        <!-- Navigation End --->