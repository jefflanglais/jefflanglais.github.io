
<?php include 'head.php';?>
       
<!-- Content Start --->


<section class="wrapper">
    <div class="container">
        <section>
            <h2 class="page-title">Picture Perfect.</h2>
            <h3 class="section-title">The Timbers: See for yourself. </h3>
            
            <figure class="thumb"><a href="img/gallery/full/DSC_0971.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0971.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0975.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0975.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0978.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0978.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0979.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0979.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0980.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0980.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0981.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0981.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0982.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0982.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0984.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0984.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0985.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0985.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0986.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0986.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0987.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0987.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0988.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0988.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0997.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0997.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_0998.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_0998.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1123.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1123.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1124.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1124.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1126.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1126.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1127.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1127.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1128.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1128.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1129.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1129.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1130.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1130.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1131.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1131.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1138.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1138.jpg" /></a></figure>
            <figure class="thumb"><a href="img/gallery/full/DSC_1145.jpg" data-lightbox="photo-gallery"><img src="img/gallery/thumb/DSC_1145.jpg" /></a></figure>
            
        </section>
    </div>
</section>



<?php include 'panels/mountain.php';?>
<!-- Content End --->     

<?php include 'footer.php';?>